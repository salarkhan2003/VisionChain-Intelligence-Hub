
export interface DatabaseSchema {
  stores: {
    id: number;
    name: string;
    location: string;
    manager_name: string | null;
    created_at: string;
  };
  
  shelves: {
    id: number;
    store_id: number;
    shelf_code: string;
    location: string;
    category: string;
    max_capacity: number;
    current_stock: number;
    last_updated: string;
  };
  
  products: {
    id: number;
    name: string;
    sku: string;
    category: string;
    price: number;
    min_stock_threshold: number;
    created_at: string;
  };
  
  inventory_events: {
    id: number;
    shelf_id: number;
    product_id: number;
    event_type: string;
    quantity_change: number;
    confidence_score: number;
    ai_analysis: string | null;
    timestamp: string;
  };
  
  theft_alerts: {
    id: number;
    shelf_id: number;
    alert_type: string;
    severity: string;
    description: string;
    ai_recommendation: string | null;
    status: string;
    created_at: string;
    resolved_at: string | null;
  };
  
  delivery_routes: {
    id: number;
    store_id: number;
    route_name: string;
    destinations: string;
    optimized_path: string | null;
    estimated_time: number | null;
    ev_battery_usage: number | null;
    weather_conditions: string | null;
    status: string;
    ai_insights: string | null;
    created_at: string;
  };
  
  demand_forecasts: {
    id: number;
    product_id: number;
    store_id: number;
    forecast_date: string;
    predicted_demand: number;
    confidence_level: number;
    seasonal_factors: string | null;
    ai_reasoning: string | null;
    created_at: string;
  };
}
