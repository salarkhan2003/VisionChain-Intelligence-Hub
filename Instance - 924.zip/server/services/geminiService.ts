
import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI('AIzaSyCZ3XGzKPYWP8cjWWwVv2AzmuE7a2Arw50');

export class GeminiAIService {
  private model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

  async analyzeInventoryEvent(eventData: {
    eventType: string;
    productName: string;
    quantityChange: number;
    timestamp: string;
    shelfLocation: string;
    confidenceScore: number;
  }) {
    const prompt = `
    Analyze this retail inventory event and provide insights:
    
    Event Type: ${eventData.eventType}
    Product: ${eventData.productName}
    Quantity Change: ${eventData.quantityChange}
    Location: ${eventData.shelfLocation}
    Confidence: ${eventData.confidenceScore}
    Time: ${eventData.timestamp}
    
    Please provide:
    1. Risk assessment (low/medium/high)
    2. Recommended actions
    3. Potential causes
    4. Prevention strategies
    
    Format as JSON with fields: riskLevel, recommendations, causes, prevention
    `;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Gemini AI analysis error:', error);
      return 'AI analysis unavailable';
    }
  }

  async generateTheftAlert(alertData: {
    shelfLocation: string;
    suspiciousActivity: string;
    productCategory: string;
    timeOfDay: string;
  }) {
    const prompt = `
    Generate a theft prevention alert and recommendation:
    
    Location: ${alertData.shelfLocation}
    Activity: ${alertData.suspiciousActivity}
    Product Category: ${alertData.productCategory}
    Time: ${alertData.timeOfDay}
    
    Provide:
    1. Alert severity (LOW/MEDIUM/HIGH/CRITICAL)
    2. Immediate actions for staff
    3. Long-term prevention measures
    4. Security recommendations
    
    Keep response concise and actionable.
    `;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Gemini theft alert error:', error);
      return 'Enhanced security monitoring recommended';
    }
  }

  async optimizeDeliveryRoute(routeData: {
    destinations: string[];
    vehicleType: string;
    batteryLevel: number;
    weatherConditions: string;
    urgencyLevel: string;
  }) {
    const prompt = `
    Optimize this delivery route with AI insights:
    
    Destinations: ${routeData.destinations.join(', ')}
    Vehicle: ${routeData.vehicleType}
    Battery Level: ${routeData.batteryLevel}%
    Weather: ${routeData.weatherConditions}
    Urgency: ${routeData.urgencyLevel}
    
    Provide:
    1. Optimal route sequence
    2. Estimated delivery time
    3. Battery consumption prediction
    4. Weather impact assessment
    5. Alternative route suggestions
    
    Focus on efficiency and reliability.
    `;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Gemini route optimization error:', error);
      return 'Standard route optimization applied';
    }
  }

  async forecastDemand(demandData: {
    productName: string;
    historicalSales: number[];
    seasonalTrends: string;
    localEvents: string;
    weatherForecast: string;
    dayOfWeek: string;
  }) {
    const prompt = `
    Generate demand forecast for retail product:
    
    Product: ${demandData.productName}
    Historical Sales: ${demandData.historicalSales.join(', ')}
    Seasonal Trends: ${demandData.seasonalTrends}
    Local Events: ${demandData.localEvents}
    Weather: ${demandData.weatherForecast}
    Day: ${demandData.dayOfWeek}
    
    Predict:
    1. Expected demand (units)
    2. Confidence level (0-100%)
    3. Key influencing factors
    4. Restock recommendations
    5. Risk factors
    
    Provide numerical forecast and reasoning.
    `;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Gemini demand forecast error:', error);
      return 'Historical average-based forecast applied';
    }
  }

  async analyzeCustomerBehavior(behaviorData: {
    shelfInteractions: number;
    averageTimeSpent: number;
    productCategory: string;
    timeOfDay: string;
    dayOfWeek: string;
  }) {
    const prompt = `
    Analyze customer shopping behavior patterns:
    
    Shelf Interactions: ${behaviorData.shelfInteractions}
    Time Spent: ${behaviorData.averageTimeSpent} minutes
    Category: ${behaviorData.productCategory}
    Time: ${behaviorData.timeOfDay}
    Day: ${behaviorData.dayOfWeek}
    
    Insights needed:
    1. Behavior classification
    2. Purchase probability
    3. Engagement level
    4. Marketing opportunities
    5. Store layout optimization
    
    Provide actionable retail insights.
    `;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Gemini behavior analysis error:', error);
      return 'Standard customer interaction logged';
    }
  }

  async generateStoreInsights(storeData: {
    totalSales: number;
    footTraffic: number;
    inventoryTurnover: number;
    theftIncidents: number;
    customerSatisfaction: number;
  }) {
    const prompt = `
    Generate comprehensive store performance insights:
    
    Sales: $${storeData.totalSales}
    Foot Traffic: ${storeData.footTraffic} customers
    Inventory Turnover: ${storeData.inventoryTurnover}x
    Theft Incidents: ${storeData.theftIncidents}
    Customer Satisfaction: ${storeData.customerSatisfaction}%
    
    Provide:
    1. Overall performance assessment
    2. Key improvement areas
    3. Operational recommendations
    4. Revenue optimization strategies
    5. Risk mitigation plans
    
    Executive summary format preferred.
    `;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Gemini store insights error:', error);
      return 'Performance metrics within normal range';
    }
  }
}

export const geminiAI = new GeminiAIService();
