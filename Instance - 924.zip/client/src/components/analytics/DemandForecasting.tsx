
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Brain, TrendingUp, Calendar, Target } from 'lucide-react';

export function DemandForecasting() {
  const [selectedProduct, setSelectedProduct] = React.useState('');
  const [selectedStore, setSelectedStore] = React.useState('');
  const [forecasting, setForecasting] = React.useState(false);
  const [lastForecast, setLastForecast] = React.useState<any>(null);

  const products = [
    { id: '1', name: 'iPhone 15 Pro' },
    { id: '2', name: 'Samsung Galaxy S24' },
    { id: '3', name: 'Coca Cola 12-Pack' },
    { id: '4', name: 'Bread - White Loaf' },
    { id: '5', name: 'Nike Air Max Shoes' },
    { id: '6', name: 'Laundry Detergent' }
  ];

  const stores = [
    { id: '1', name: 'Walmart Supercenter #1' },
    { id: '2', name: 'Walmart Neighborhood Market #2' },
    { id: '3', name: 'Walmart Express #3' }
  ];

  async function handleGenerateForecast() {
    if (!selectedProduct || !selectedStore) return;
    
    setForecasting(true);
    try {
      const response = await fetch('/api/forecast/demand', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: parseInt(selectedProduct),
          storeId: parseInt(selectedStore)
        })
      });

      if (response.ok) {
        const result = await response.json();
        setLastForecast({
          predictedDemand: result.predictedDemand,
          confidenceLevel: result.confidenceLevel,
          aiReasoning: result.aiReasoning,
          timestamp: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error('Forecast generation failed:', error);
    } finally {
      setForecasting(false);
    }
  }

  const historicalForecasts = [
    {
      product: 'iPhone 15 Pro',
      predicted: 45,
      actual: 42,
      accuracy: 93,
      date: '2024-01-15'
    },
    {
      product: 'Nike Air Max',
      predicted: 28,
      actual: 31,
      accuracy: 89,
      date: '2024-01-14'
    },
    {
      product: 'Coca Cola',
      predicted: 156,
      actual: 149,
      accuracy: 95,
      date: '2024-01-13'
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Brain className="h-5 w-5" />
          <span>AI Demand Forecasting</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Select Product</Label>
            <Select value={selectedProduct} onValueChange={setSelectedProduct}>
              <SelectTrigger>
                <SelectValue placeholder="Choose product..." />
              </SelectTrigger>
              <SelectContent>
                {products.map((product) => (
                  <SelectItem key={product.id} value={product.id}>
                    {product.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Select Store</Label>
            <Select value={selectedStore} onValueChange={setSelectedStore}>
              <SelectTrigger>
                <SelectValue placeholder="Choose store..." />
              </SelectTrigger>
              <SelectContent>
                {stores.map((store) => (
                  <SelectItem key={store.id} value={store.id}>
                    {store.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button
          onClick={handleGenerateForecast}
          disabled={!selectedProduct || !selectedStore || forecasting}
          className="w-full"
        >
          {forecasting ? 'Generating Forecast...' : 'Generate AI Forecast'}
        </Button>

        {lastForecast && (
          <div className="border-t pt-4">
            <h4 className="font-medium mb-3 flex items-center">
              <TrendingUp className="h-4 w-4 mr-2 text-green-500" />
              Latest Forecast
            </h4>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600">{lastForecast.predictedDemand}</p>
                  <p className="text-sm text-gray-600">Predicted Units</p>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">{lastForecast.confidenceLevel}%</p>
                  <p className="text-sm text-gray-600">Confidence Level</p>
                </div>
              </div>
              
              <div className="bg-purple-50 p-3 rounded-md">
                <p className="text-sm text-purple-800">
                  <strong>AI Analysis:</strong> {lastForecast.aiReasoning?.substring(0, 200)}...
                </p>
              </div>
              
              <p className="text-xs text-gray-500">
                Generated: {new Date(lastForecast.timestamp).toLocaleString()}
              </p>
            </div>
          </div>
        )}

        <div className="border-t pt-4">
          <h4 className="font-medium mb-3 flex items-center">
            <Target className="h-4 w-4 mr-2 text-blue-500" />
            Recent Forecast Accuracy
          </h4>
          <div className="space-y-2">
            {historicalForecasts.map((forecast, index) => (
              <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                <div>
                  <p className="text-sm font-medium">{forecast.product}</p>
                  <p className="text-xs text-gray-500">
                    Predicted: {forecast.predicted} | Actual: {forecast.actual}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={
                    forecast.accuracy >= 95 ? 'bg-green-100 text-green-800' :
                    forecast.accuracy >= 90 ? 'bg-blue-100 text-blue-800' :
                    'bg-yellow-100 text-yellow-800'
                  }>
                    {forecast.accuracy}%
                  </Badge>
                  <span className="text-xs text-gray-500">{forecast.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
