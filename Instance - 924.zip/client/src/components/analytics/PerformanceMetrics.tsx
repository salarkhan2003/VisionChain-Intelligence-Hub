
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { BarChart3, Eye, Shield, Zap } from 'lucide-react';

export function PerformanceMetrics() {
  const metrics = [
    {
      name: 'Computer Vision Accuracy',
      value: 94.8,
      target: 95,
      icon: Eye,
      color: 'text-blue-600',
      status: 'good'
    },
    {
      name: 'Theft Detection Rate',
      value: 89.2,
      target: 90,
      icon: Shield,
      color: 'text-red-600',
      status: 'warning'
    },
    {
      name: 'Route Optimization Efficiency',
      value: 96.5,
      target: 95,
      icon: Zap,
      color: 'text-green-600',
      status: 'excellent'
    },
    {
      name: 'Demand Forecast Accuracy',
      value: 91.7,
      target: 85,
      icon: BarChart3,
      color: 'text-purple-600',
      status: 'excellent'
    }
  ];

  const kpis = [
    {
      name: 'Average Response Time',
      value: '4.2 minutes',
      change: '-30 seconds',
      trend: 'up'
    },
    {
      name: 'False Positive Rate',
      value: '3.2%',
      change: '-0.8%',
      trend: 'up'
    },
    {
      name: 'System Uptime',
      value: '99.8%',
      change: '+0.2%',
      trend: 'up'
    },
    {
      name: 'Energy Efficiency',
      value: '87%',
      change: '+5%',
      trend: 'up'
    }
  ];

  function getStatusColor(status: string) {
    switch (status) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  function getStatusLabel(status: string) {
    return status.charAt(0).toUpperCase() + status.slice(1);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <BarChart3 className="h-5 w-5" />
          <span>System Performance Metrics</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h4 className="font-medium">AI Model Performance</h4>
          {metrics.map((metric) => {
            const Icon = metric.icon;
            return (
              <div key={metric.name} className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Icon className={`h-4 w-4 ${metric.color}`} />
                    <span className="text-sm font-medium">{metric.name}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold">{metric.value}%</span>
                    <Badge className={getStatusColor(metric.status)}>
                      {getStatusLabel(metric.status)}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress value={metric.value} className="flex-1" />
                  <span className="text-xs text-gray-500">Target: {metric.target}%</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="border-t pt-4">
          <h4 className="font-medium mb-3">Key Performance Indicators</h4>
          <div className="grid grid-cols-2 gap-4">
            {kpis.map((kpi) => (
              <div key={kpi.name} className="p-3 border rounded-lg">
                <div className="flex justify-between items-start mb-1">
                  <p className="text-sm text-gray-600">{kpi.name}</p>
                  <span className={`text-xs ${
                    kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {kpi.change}
                  </span>
                </div>
                <p className="text-lg font-bold">{kpi.value}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t pt-4">
          <h4 className="font-medium mb-3">System Health Summary</h4>
          <div className="space-y-2">
            <div className="flex justify-between items-center p-2 bg-green-50 rounded">
              <span className="text-sm">Overall System Status</span>
              <Badge className="bg-green-100 text-green-800">Operational</Badge>
            </div>
            <div className="flex justify-between items-center p-2 bg-blue-50 rounded">
              <span className="text-sm">AI Models</span>
              <Badge className="bg-blue-100 text-blue-800">4/4 Active</Badge>
            </div>
            <div className="flex justify-between items-center p-2 bg-purple-50 rounded">
              <span className="text-sm">Data Processing</span>
              <Badge className="bg-purple-100 text-purple-800">Real-time</Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
