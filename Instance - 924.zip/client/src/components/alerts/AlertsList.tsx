
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, Clock, Eye } from 'lucide-react';

interface Alert {
  id: number;
  alert_type: string;
  severity: string;
  description: string;
  ai_recommendation: string;
  status: string;
  created_at: string;
  shelf_code: string;
  store_name: string;
}

export function AlertsList() {
  const [alerts, setAlerts] = React.useState<Alert[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetchAlerts();
  }, []);

  async function fetchAlerts() {
    try {
      const response = await fetch('/api/alerts');
      if (response.ok) {
        const data = await response.json();
        setAlerts(data);
      }
    } catch (error) {
      console.error('Failed to fetch alerts:', error);
    } finally {
      setLoading(false);
    }
  }

  async function resolveAlert(alertId: number) {
    try {
      const response = await fetch(`/api/alerts/${alertId}/resolve`, {
        method: 'PUT'
      });
      
      if (response.ok) {
        setAlerts(alerts.map(alert => 
          alert.id === alertId 
            ? { ...alert, status: 'resolved' }
            : alert
        ));
      }
    } catch (error) {
      console.error('Failed to resolve alert:', error);
    }
  }

  function getSeverityColor(severity: string) {
    switch (severity.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  function getAlertIcon(alertType: string) {
    switch (alertType) {
      case 'theft_detected': return AlertTriangle;
      case 'suspicious_activity': return Eye;
      default: return AlertTriangle;
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5" />
            <span>Active Security Alerts</span>
          </div>
          <Badge variant="outline">
            {alerts.filter(a => a.status === 'active').length} Active
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-20 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        ) : alerts.length === 0 ? (
          <div className="text-center py-8">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <p className="text-gray-500">No security alerts</p>
            <p className="text-sm text-gray-400">All systems operating normally</p>
          </div>
        ) : (
          <div className="space-y-4">
            {alerts.map((alert) => {
              const Icon = getAlertIcon(alert.alert_type);
              
              return (
                <div key={alert.id} className={`border rounded-lg p-4 ${
                  alert.status === 'resolved' ? 'opacity-60' : ''
                }`}>
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-md ${
                        alert.severity === 'CRITICAL' ? 'bg-red-100' :
                        alert.severity === 'HIGH' ? 'bg-orange-100' :
                        'bg-yellow-100'
                      }`}>
                        <Icon className={`h-4 w-4 ${
                          alert.severity === 'CRITICAL' ? 'text-red-600' :
                          alert.severity === 'HIGH' ? 'text-orange-600' :
                          'text-yellow-600'
                        }`} />
                      </div>
                      <div>
                        <h4 className="font-medium capitalize">
                          {alert.alert_type.replace('_', ' ')}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {alert.shelf_code} • {alert.store_name}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getSeverityColor(alert.severity)}>
                        {alert.severity}
                      </Badge>
                      {alert.status === 'resolved' && (
                        <Badge className="bg-green-100 text-green-800">
                          Resolved
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-700 mb-3">{alert.description}</p>
                  
                  {alert.ai_recommendation && (
                    <div className="bg-blue-50 p-3 rounded-md mb-3">
                      <p className="text-sm text-blue-800">
                        <strong>AI Recommendation:</strong> {alert.ai_recommendation.substring(0, 150)}...
                      </p>
                    </div>
                  )}
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <Clock className="h-3 w-3" />
                      <span>{new Date(alert.created_at).toLocaleString()}</span>
                    </div>
                    
                    {alert.status === 'active' && (
                      <Button
                        size="sm"
                        onClick={() => resolveAlert(alert.id)}
                        className="flex items-center space-x-1"
                      >
                        <CheckCircle className="h-3 w-3" />
                        <span>Resolve</span>
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
