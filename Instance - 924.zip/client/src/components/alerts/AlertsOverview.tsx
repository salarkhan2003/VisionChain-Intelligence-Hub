
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, Shield, Eye, Clock } from 'lucide-react';

export function AlertsOverview() {
  const stats = [
    {
      name: 'Active Alerts',
      value: '3',
      icon: AlertTriangle,
      color: 'text-red-600',
      bgColor: 'bg-red-100',
      change: '+2 from yesterday'
    },
    {
      name: 'Resolved Today',
      value: '12',
      icon: Shield,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      change: '+5 from yesterday'
    },
    {
      name: 'Detection Accuracy',
      value: '94.8%',
      icon: Eye,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
      change: '+1.2% this week'
    },
    {
      name: 'Avg Response Time',
      value: '4.2 min',
      icon: Clock,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
      change: '-30s from last week'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.name}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {stat.name}
              </CardTitle>
              <div className={`${stat.bgColor} p-2 rounded-md`}>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
              <p className="text-xs text-gray-500 mt-1">{stat.change}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
