
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, Camera, Wifi, AlertTriangle, Play } from 'lucide-react';

export function SecurityMonitoring() {
  const [monitoring, setMonitoring] = React.useState(true);

  const cameras = [
    {
      id: 1,
      name: 'Main Entrance',
      status: 'active',
      alerts: 0,
      lastEvent: '2 minutes ago'
    },
    {
      id: 2,
      name: 'Electronics Aisle',
      status: 'active',
      alerts: 1,
      lastEvent: '5 minutes ago'
    },
    {
      id: 3,
      name: 'Checkout Area',
      status: 'active',
      alerts: 0,
      lastEvent: '1 minute ago'
    },
    {
      id: 4,
      name: 'Storage Room',
      status: 'maintenance',
      alerts: 0,
      lastEvent: '1 hour ago'
    }
  ];

  const recentEvents = [
    {
      id: 1,
      type: 'Motion Detected',
      camera: 'Electronics Aisle',
      time: '2 minutes ago',
      severity: 'low'
    },
    {
      id: 2,
      type: 'Suspicious Activity',
      camera: 'Main Entrance',
      time: '8 minutes ago',
      severity: 'medium'
    },
    {
      id: 3,
      type: 'Item Removed',
      camera: 'Electronics Aisle',
      time: '12 minutes ago',
      severity: 'low'
    }
  ];

  function getStatusColor(status: string) {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'maintenance': return 'bg-yellow-100 text-yellow-800';
      case 'offline': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  function getSeverityColor(severity: string) {
    switch (severity) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Security Monitoring</span>
          </div>
          <Button
            size="sm"
            variant={monitoring ? "outline" : "default"}
            onClick={() => setMonitoring(!monitoring)}
          >
            {monitoring ? "Pause" : "Resume"}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h4 className="font-medium mb-3">Camera Status</h4>
          <div className="space-y-3">
            {cameras.map((camera) => (
              <div key={camera.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Camera className="h-4 w-4 text-gray-600" />
                  <div>
                    <p className="text-sm font-medium">{camera.name}</p>
                    <p className="text-xs text-gray-500">Last: {camera.lastEvent}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {camera.alerts > 0 && (
                    <Badge className="bg-red-100 text-red-800">
                      {camera.alerts} alert{camera.alerts > 1 ? 's' : ''}
                    </Badge>
                  )}
                  <Badge className={getStatusColor(camera.status)}>
                    {camera.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-medium mb-3">Recent Events</h4>
          <div className="space-y-2">
            {recentEvents.map((event) => (
              <div key={event.id} className="flex justify-between items-center p-2 text-sm">
                <div className="flex items-center space-x-2">
                  <Badge className={getSeverityColor(event.severity)}>
                    {event.severity}
                  </Badge>
                  <span>{event.type}</span>
                </div>
                <div className="text-gray-500 text-xs">
                  {event.camera} • {event.time}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t pt-4">
          <h4 className="font-medium mb-3">System Health</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="h-2 w-2 bg-green-500 rounded-full"></div>
              <span>Network: Online</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="h-2 w-2 bg-green-500 rounded-full"></div>
              <span>Storage: 78% Free</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="h-2 w-2 bg-yellow-500 rounded-full"></div>
              <span>CPU: 65% Load</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="h-2 w-2 bg-green-500 rounded-full"></div>
              <span>Memory: 4.2GB Free</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
