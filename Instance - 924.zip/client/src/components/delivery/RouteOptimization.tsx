
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Route, MapPin, Zap, Clock } from 'lucide-react';

export function RouteOptimization() {
  const [selectedStore, setSelectedStore] = React.useState('');
  const [destinations, setDestinations] = React.useState('');
  const [optimizing, setOptimizing] = React.useState(false);
  const [lastOptimization, setLastOptimization] = React.useState<any>(null);

  const stores = [
    { id: '1', name: 'Walmart Supercenter #1' },
    { id: '2', name: 'Walmart Neighborhood Market #2' },
    { id: '3', name: 'Walmart Express #3' }
  ];

  async function handleOptimizeRoute() {
    if (!selectedStore || !destinations) return;
    
    setOptimizing(true);
    try {
      const destinationList = destinations.split('\n').filter(d => d.trim());
      const response = await fetch('/api/delivery/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storeId: parseInt(selectedStore),
          destinations: destinationList,
          vehicleType: 'EV Van'
        })
      });

      if (response.ok) {
        const result = await response.json();
        setLastOptimization({
          estimatedTime: result.estimatedTime,
          batteryUsage: result.batteryUsage,
          aiInsights: result.aiInsights,
          timestamp: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error('Route optimization failed:', error);
    } finally {
      setOptimizing(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Route className="h-5 w-5" />
          <span>AI Route Optimization</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="store-select">Select Store</Label>
          <Select value={selectedStore} onValueChange={setSelectedStore}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a store..." />
            </SelectTrigger>
            <SelectContent>
              {stores.map((store) => (
                <SelectItem key={store.id} value={store.id}>
                  {store.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="destinations">Delivery Destinations</Label>
          <textarea
            className="w-full p-3 border rounded-md h-24 text-sm"
            placeholder="Enter addresses (one per line)&#10;123 Main Street&#10;456 Oak Avenue&#10;789 Pine Road"
            value={destinations}
            onChange={(e) => setDestinations(e.target.value)}
          />
        </div>

        <Button
          onClick={handleOptimizeRoute}
          disabled={!selectedStore || !destinations || optimizing}
          className="w-full"
        >
          {optimizing ? 'Optimizing...' : 'Optimize Route with AI'}
        </Button>

        {lastOptimization && (
          <div className="border-t pt-4">
            <h4 className="font-medium mb-3">Optimization Results</h4>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Estimated Time</p>
                    <p className="font-semibold">{lastOptimization.estimatedTime} minutes</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Zap className="h-4 w-4 text-green-600" />
                  <div>
                    <p className="text-sm text-gray-600">Battery Usage</p>
                    <p className="font-semibold">{lastOptimization.batteryUsage}%</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-blue-50 p-3 rounded-md">
                <p className="text-sm text-blue-800">
                  <strong>AI Insights:</strong> {lastOptimization.aiInsights?.substring(0, 200)}...
                </p>
              </div>
              
              <p className="text-xs text-gray-500">
                Generated: {new Date(lastOptimization.timestamp).toLocaleString()}
              </p>
            </div>
          </div>
        )}

        <div className="border-t pt-4">
          <h4 className="font-medium mb-3">Quick Routes</h4>
          <div className="space-y-2">
            <Button variant="outline" size="sm" className="w-full justify-start">
              <MapPin className="h-3 w-3 mr-2" />
              Downtown Circuit (8 stops)
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <MapPin className="h-3 w-3 mr-2" />
              Suburban Loop (12 stops)
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <MapPin className="h-3 w-3 mr-2" />
              Express Highway (5 stops)
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
