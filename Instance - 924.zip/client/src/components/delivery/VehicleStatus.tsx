
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Truck, Battery, MapPin, Clock } from 'lucide-react';

export function VehicleStatus() {
  const vehicles = [
    {
      id: 1,
      name: 'EV Van #1',
      driver: 'John Smith',
      batteryLevel: 87,
      status: 'delivering',
      currentLocation: '456 Oak Avenue',
      nextStop: '789 Pine Road',
      eta: '12 min',
      packagesLeft: 8
    },
    {
      id: 2,
      name: 'EV Van #2',
      driver: 'Sarah Johnson',
      batteryLevel: 65,
      status: 'en_route',
      currentLocation: 'Charging Station A',
      nextStop: '123 Main Street',
      eta: '25 min',
      packagesLeft: 12
    },
    {
      id: 3,
      name: 'EV Van #3',
      driver: 'Mike Chen',
      batteryLevel: 92,
      status: 'loading',
      currentLocation: 'Warehouse',
      nextStop: 'Route Start',
      eta: '5 min',
      packagesLeft: 15
    },
    {
      id: 4,
      name: 'EV Van #4',
      driver: 'Amanda Rodriguez',
      batteryLevel: 23,
      status: 'charging',
      currentLocation: 'Charging Station B',
      nextStop: 'Pending',
      eta: '45 min',
      packagesLeft: 0
    }
  ];

  function getStatusColor(status: string) {
    switch (status) {
      case 'delivering': return 'bg-green-100 text-green-800';
      case 'en_route': return 'bg-blue-100 text-blue-800';
      case 'loading': return 'bg-yellow-100 text-yellow-800';
      case 'charging': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  function getBatteryColor(level: number) {
    if (level > 60) return 'bg-green-500';
    if (level > 30) return 'bg-yellow-500';
    return 'bg-red-500';
  }

  function getStatusLabel(status: string) {
    switch (status) {
      case 'delivering': return 'Delivering';
      case 'en_route': return 'En Route';
      case 'loading': return 'Loading';
      case 'charging': return 'Charging';
      default: return 'Unknown';
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Truck className="h-5 w-5" />
          <span>Vehicle Fleet Status</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {vehicles.map((vehicle) => (
          <div key={vehicle.id} className="border rounded-lg p-4 space-y-3">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-semibold">{vehicle.name}</h4>
                <p className="text-sm text-gray-600">Driver: {vehicle.driver}</p>
              </div>
              <Badge className={getStatusColor(vehicle.status)}>
                {getStatusLabel(vehicle.status)}
              </Badge>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Battery className="h-4 w-4 text-gray-600" />
                  <span className="text-sm">Battery Level</span>
                </div>
                <span className="text-sm font-medium">{vehicle.batteryLevel}%</span>
              </div>
              <Progress 
                value={vehicle.batteryLevel} 
                className="w-full"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="flex items-center space-x-1 text-gray-600 mb-1">
                  <MapPin className="h-3 w-3" />
                  <span>Current Location</span>
                </div>
                <p className="font-medium">{vehicle.currentLocation}</p>
              </div>
              <div>
                <div className="flex items-center space-x-1 text-gray-600 mb-1">
                  <Clock className="h-3 w-3" />
                  <span>Next Stop ETA</span>
                </div>
                <p className="font-medium">{vehicle.eta}</p>
              </div>
            </div>
            
            <div className="flex justify-between text-sm pt-2 border-t">
              <span>Next Stop: <strong>{vehicle.nextStop}</strong></span>
              <span>Packages: <strong>{vehicle.packagesLeft}</strong></span>
            </div>
          </div>
        ))}
        
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium mb-2">Fleet Summary</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Active Vehicles:</span>
              <span className="ml-2 font-medium">4/6</span>
            </div>
            <div>
              <span className="text-gray-600">Total Packages:</span>
              <span className="ml-2 font-medium">35</span>
            </div>
            <div>
              <span className="text-gray-600">Avg Battery:</span>
              <span className="ml-2 font-medium">67%</span>
            </div>
            <div>
              <span className="text-gray-600">Fleet Efficiency:</span>
              <span className="ml-2 font-medium">94%</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
