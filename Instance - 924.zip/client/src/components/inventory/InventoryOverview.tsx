
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Package, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';

interface Shelf {
  id: number;
  shelf_code: string;
  location: string;
  category: string;
  current_stock: number;
  max_capacity: number;
  store_name: string;
}

export function InventoryOverview() {
  const [shelves, setShelves] = React.useState<Shelf[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    async function fetchShelves() {
      try {
        const response = await fetch('/api/shelves');
        if (response.ok) {
          const data = await response.json();
          setShelves(data);
        }
      } catch (error) {
        console.error('Failed to fetch shelves:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchShelves();
  }, []);

  function getStockStatus(current: number, max: number) {
    const percentage = (current / max) * 100;
    if (percentage < 20) return { status: 'critical', color: 'text-red-600', bgColor: 'bg-red-100' };
    if (percentage < 50) return { status: 'low', color: 'text-yellow-600', bgColor: 'bg-yellow-100' };
    return { status: 'good', color: 'text-green-600', bgColor: 'bg-green-100' };
  }

  const totalShelves = shelves.length;
  const criticalShelves = shelves.filter(s => (s.current_stock / s.max_capacity) < 0.2).length;
  const lowStockShelves = shelves.filter(s => {
    const ratio = s.current_stock / s.max_capacity;
    return ratio >= 0.2 && ratio < 0.5;
  }).length;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Shelves</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalShelves}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Stock</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{criticalShelves}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock</CardTitle>
            <TrendingDown className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{lowStockShelves}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Well Stocked</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {totalShelves - criticalShelves - lowStockShelves}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Shelf Status Overview</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-16 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {shelves.map((shelf) => {
                const stockPercentage = (shelf.current_stock / shelf.max_capacity) * 100;
                const status = getStockStatus(shelf.current_stock, shelf.max_capacity);
                
                return (
                  <div key={shelf.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold">{shelf.shelf_code}</h4>
                        <p className="text-sm text-gray-600">{shelf.location}</p>
                        <p className="text-xs text-gray-500">{shelf.store_name}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={status.bgColor + ' ' + status.color}>
                          {shelf.current_stock}/{shelf.max_capacity}
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1">{shelf.category}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Stock Level</span>
                        <span>{Math.round(stockPercentage)}%</span>
                      </div>
                      <Progress value={stockPercentage} className="w-full" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
