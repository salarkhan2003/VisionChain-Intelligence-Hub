
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Package, Clock, CheckCircle } from 'lucide-react';

export function StockAlerts() {
  const alerts = [
    {
      id: 1,
      type: 'low_stock',
      product: 'iPhone 15 Pro',
      shelf: 'A1-ELEC',
      current: 3,
      threshold: 5,
      severity: 'high',
      timestamp: '5 minutes ago'
    },
    {
      id: 2,
      type: 'out_of_stock',
      product: 'Nike Air Max',
      shelf: 'D1-SHOE',
      current: 0,
      threshold: 8,
      severity: 'critical',
      timestamp: '12 minutes ago'
    },
    {
      id: 3,
      type: 'overstock',
      product: 'Coca Cola 12-Pack',
      shelf: 'B3-BEV',
      current: 95,
      threshold: 80,
      severity: 'medium',
      timestamp: '1 hour ago'
    },
    {
      id: 4,
      type: 'restock_needed',
      product: 'Bread - White Loaf',
      shelf: 'C2-FOOD',
      current: 12,
      threshold: 15,
      severity: 'low',
      timestamp: '2 hours ago'
    }
  ];

  function getSeverityColor(severity: string) {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  function getAlertIcon(type: string) {
    switch (type) {
      case 'out_of_stock': return AlertTriangle;
      case 'low_stock': return Package;
      case 'overstock': return Package;
      case 'restock_needed': return Clock;
      default: return AlertTriangle;
    }
  }

  function getAlertTitle(type: string) {
    switch (type) {
      case 'out_of_stock': return 'Out of Stock';
      case 'low_stock': return 'Low Stock';
      case 'overstock': return 'Overstock';
      case 'restock_needed': return 'Restock Needed';
      default: return 'Alert';
    }
  }

  async function handleResolveAlert(alertId: number) {
    // In a real app, this would call the API to resolve the alert
    console.log('Resolving alert:', alertId);
  }

  async function handleGenerateRestock(alert: any) {
    try {
      const response = await fetch('/api/forecast/demand', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: 1, storeId: 1 })
      });
      
      if (response.ok) {
        console.log('Restock order generated for:', alert.product);
      }
    } catch (error) {
      console.error('Failed to generate restock:', error);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <AlertTriangle className="h-5 w-5" />
          <span>Stock Alerts</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {alerts.map((alert) => {
          const Icon = getAlertIcon(alert.type);
          
          return (
            <div key={alert.id} className="border rounded-lg p-4 space-y-3">
              <div className="flex justify-between items-start">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-md ${
                    alert.severity === 'critical' ? 'bg-red-100' :
                    alert.severity === 'high' ? 'bg-orange-100' :
                    alert.severity === 'medium' ? 'bg-yellow-100' :
                    'bg-blue-100'
                  }`}>
                    <Icon className={`h-4 w-4 ${
                      alert.severity === 'critical' ? 'text-red-600' :
                      alert.severity === 'high' ? 'text-orange-600' :
                      alert.severity === 'medium' ? 'text-yellow-600' :
                      'text-blue-600'
                    }`} />
                  </div>
                  <div>
                    <h4 className="font-medium">{getAlertTitle(alert.type)}</h4>
                    <p className="text-sm text-gray-600">{alert.product}</p>
                  </div>
                </div>
                <Badge className={getSeverityColor(alert.severity)}>
                  {alert.severity}
                </Badge>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Current Stock:</span>
                  <span className="ml-2 font-medium">{alert.current}</span>
                </div>
                <div>
                  <span className="text-gray-600">Threshold:</span>
                  <span className="ml-2 font-medium">{alert.threshold}</span>
                </div>
                <div>
                  <span className="text-gray-600">Location:</span>
                  <span className="ml-2 font-medium">{alert.shelf}</span>
                </div>
                <div>
                  <span className="text-gray-600">Time:</span>
                  <span className="ml-2 font-medium">{alert.timestamp}</span>
                </div>
              </div>
              
              <div className="flex space-x-2">
                {alert.type !== 'overstock' && (
                  <Button
                    size="sm"
                    onClick={() => handleGenerateRestock(alert)}
                    className="flex-1"
                  >
                    Generate Restock
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleResolveAlert(alert.id)}
                  className="flex items-center space-x-1"
                >
                  <CheckCircle className="h-3 w-3" />
                  <span>Resolve</span>
                </Button>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
