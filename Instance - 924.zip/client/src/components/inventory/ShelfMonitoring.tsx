
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Wifi, Battery, Thermometer, Scale } from 'lucide-react';

export function ShelfMonitoring() {
  const sensors = [
    {
      id: 1,
      name: 'Load Cell A1-ELEC',
      type: 'Weight Sensor',
      value: '15.2 kg',
      status: 'online',
      battery: 87,
      icon: Scale
    },
    {
      id: 2,
      name: 'Ultrasonic B3-BEV',
      type: 'Proximity Sensor',
      value: '23 cm',
      status: 'online',
      battery: 92,
      icon: Wifi
    },
    {
      id: 3,
      name: 'Temperature C2-FOOD',
      type: 'Thermal Monitor',
      value: '4.2°C',
      status: 'online',
      battery: 78,
      icon: Thermometer
    },
    {
      id: 4,
      name: 'RFID Reader D1-SHOE',
      type: 'Tag Scanner',
      value: '12 items',
      status: 'warning',
      battery: 45,
      icon: Wifi
    }
  ];

  function getStatusColor(status: string) {
    switch (status) {
      case 'online': return 'bg-green-100 text-green-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'offline': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  function getBatteryColor(level: number) {
    if (level > 60) return 'text-green-600';
    if (level > 30) return 'text-yellow-600';
    return 'text-red-600';
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Wifi className="h-5 w-5" />
          <span>IoT Sensor Network</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {sensors.map((sensor) => {
          const Icon = sensor.icon;
          return (
            <div key={sensor.id} className="border rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-100 p-2 rounded-md">
                    <Icon className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">{sensor.name}</h4>
                    <p className="text-sm text-gray-600">{sensor.type}</p>
                  </div>
                </div>
                <Badge className={getStatusColor(sensor.status)}>
                  {sensor.status}
                </Badge>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Current Reading</p>
                  <p className="text-lg font-semibold">{sensor.value}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Battery Level</p>
                  <div className="flex items-center space-x-2">
                    <Battery className={`h-4 w-4 ${getBatteryColor(sensor.battery)}`} />
                    <span className={`font-semibold ${getBatteryColor(sensor.battery)}`}>
                      {sensor.battery}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium mb-2">Network Statistics</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Active Sensors:</span>
              <span className="ml-2 font-medium">4/4</span>
            </div>
            <div>
              <span className="text-gray-600">Data Rate:</span>
              <span className="ml-2 font-medium">1.2 MB/h</span>
            </div>
            <div>
              <span className="text-gray-600">Uptime:</span>
              <span className="ml-2 font-medium">99.8%</span>
            </div>
            <div>
              <span className="text-gray-600">Last Sync:</span>
              <span className="ml-2 font-medium">2s ago</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
