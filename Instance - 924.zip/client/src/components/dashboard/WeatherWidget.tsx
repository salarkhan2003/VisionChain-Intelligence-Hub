import * as React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Cloud, Sun, CloudRain } from 'lucide-react';

export function WeatherWidget() {
  const weather = {
    temperature: 72,
    condition: 'Partly Cloudy',
    humidity: 65,
    windSpeed: 8
  };

  const getWeatherIcon = () => {
    switch (weather.condition) {
      case 'Sunny': return <Sun className="h-8 w-8 text-orange-400" />;
      case 'Rainy': return <CloudRain className="h-8 w-8 text-cyan-400" />;
      default: return <Cloud className="h-8 w-8 text-slate-300" />;
    }
  };

  return (
    <Card className="glass-effect border-0 text-white bg-slate-800/30">
      <CardContent className="p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-shrink-0">
            {getWeatherIcon()}
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-100">{weather.temperature}°F</div>
            <div className="text-sm text-slate-300">{weather.condition}</div>
            <div className="text-xs text-slate-400 mt-1">
              Humidity: {weather.humidity}% • Wind: {weather.windSpeed} mph
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
