
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Bot, Send, User, Lightbulb, TrendingUp, AlertTriangle } from 'lucide-react';

interface Message {
  id: number;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

export function AIAssistant() {
  const [messages, setMessages] = React.useState<Message[]>([
    {
      id: 1,
      type: 'bot',
      content: 'Hello! I\'m your AI assistant for VisionChain. I can help you with inventory insights, theft analysis, route optimization, and demand forecasting. What would you like to know?',
      timestamp: new Date(),
      suggestions: ['Show inventory alerts', 'Optimize delivery routes', 'Analyze sales trends', 'Security recommendations']
    }
  ]);
  const [input, setInput] = React.useState('');
  const [isTyping, setIsTyping] = React.useState(false);

  const quickSuggestions = [
    { text: 'Show theft patterns', icon: AlertTriangle },
    { text: 'Demand forecast', icon: TrendingUp },
    { text: 'Optimization tips', icon: Lightbulb }
  ];

  const handleSendMessage = async (message: string) => {
    if (!message.trim()) return;

    const userMessage: Message = {
      id: Date.now(),
      type: 'user',
      content: message,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const botResponse: Message = {
        id: Date.now() + 1,
        type: 'bot',
        content: generateAIResponse(message),
        timestamp: new Date(),
        suggestions: ['Tell me more', 'Show data', 'Generate report']
      };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const generateAIResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('theft') || lowerInput.includes('security')) {
      return 'Based on current data, I\'ve detected 3 potential security concerns in Electronics (Aisle A1). The AI vision system shows suspicious activity patterns between 2-4 PM. I recommend increasing staff presence during these hours and reviewing camera footage.';
    }
    
    if (lowerInput.includes('inventory') || lowerInput.includes('stock')) {
      return 'Current inventory analysis shows: 2 critical stock items (iPhone 15 Pro, Nike Air Max), 5 items need restocking within 24 hours. AI forecasting suggests 23% increase in demand for Electronics this weekend. Shall I generate automatic restock orders?';
    }
    
    if (lowerInput.includes('route') || lowerInput.includes('delivery')) {
      return 'Delivery optimization analysis complete! I\'ve identified a 18% efficiency improvement opportunity by adjusting Route #3. Weather conditions are optimal, and EV battery levels are sufficient. The optimized route saves 12 minutes and reduces battery usage by 8%.';
    }
    
    if (lowerInput.includes('forecast') || lowerInput.includes('demand')) {
      return 'Demand forecasting shows strong patterns: Beverages +15% (weather impact), Electronics +25% (weekend trend), Groceries stable. Black Friday preparation should focus on Electronics inventory. AI confidence level: 94.2%.';
    }
    
    return 'I understand you\'re asking about retail operations. Based on current data patterns, I can provide specific insights about inventory management, security alerts, delivery optimization, or demand forecasting. What specific area interests you most?';
  };

  return (
    <Card className="h-[600px] flex flex-col card-hover">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
            <Bot className="h-4 w-4 text-white" />
          </div>
          <span>AI Assistant</span>
          <Badge className="bg-green-100 text-green-800 status-indicator">
            Online
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col space-y-4">
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-lg p-3 ${
                  message.type === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  <div className="flex items-start space-x-2">
                    {message.type === 'bot' && (
                      <Bot className="h-4 w-4 mt-0.5 text-blue-600" />
                    )}
                    {message.type === 'user' && (
                      <User className="h-4 w-4 mt-0.5 text-white" />
                    )}
                    <div className="flex-1">
                      <p className="text-sm">{message.content}</p>
                      <p className={`text-xs mt-1 ${
                        message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                      }`}>
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  
                  {message.suggestions && (
                    <div className="mt-3 space-y-1">
                      {message.suggestions.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="ghost"
                          size="sm"
                          className="h-6 text-xs bg-white bg-opacity-20 hover:bg-opacity-30 text-gray-700"
                          onClick={() => handleSendMessage(suggestion)}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-lg p-3 max-w-[80%]">
                  <div className="flex items-center space-x-2">
                    <Bot className="h-4 w-4 text-blue-600" />
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        
        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {quickSuggestions.map((suggestion, index) => {
              const Icon = suggestion.icon;
              return (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="text-xs interactive-element"
                  onClick={() => handleSendMessage(suggestion.text)}
                >
                  <Icon className="h-3 w-3 mr-1" />
                  {suggestion.text}
                </Button>
              );
            })}
          </div>
          
          <div className="flex space-x-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about inventory, security, or forecasting..."
              className="flex-1"
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(input)}
            />
            <Button
              onClick={() => handleSendMessage(input)}
              disabled={!input.trim() || isTyping}
              className="walmart-gradient"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
