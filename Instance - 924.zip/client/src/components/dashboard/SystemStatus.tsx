
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Camera, Wifi, Database, Cpu, Battery, Shield, Cloud, Zap } from 'lucide-react';

export function SystemStatus() {
  const [systemMetrics, setSystemMetrics] = React.useState({
    cpuUsage: 65,
    memoryUsage: 78,
    diskUsage: 45,
    networkLatency: 12
  });

  React.useEffect(() => {
    const interval = setInterval(() => {
      setSystemMetrics(prev => ({
        cpuUsage: Math.max(50, Math.min(90, prev.cpuUsage + (Math.random() - 0.5) * 10)),
        memoryUsage: Math.max(60, Math.min(85, prev.memoryUsage + (Math.random() - 0.5) * 5)),
        diskUsage: Math.max(40, Math.min(60, prev.diskUsage + (Math.random() - 0.5) * 2)),
        networkLatency: Math.max(8, Math.min(25, prev.networkLatency + (Math.random() - 0.5) * 3))
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const systems = [
    {
      name: 'Computer Vision',
      status: 'online',
      icon: Camera,
      description: 'YOLOv8 detection active',
      health: 98,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      name: 'IoT Sensor Network',
      status: 'online',
      icon: Wifi,
      description: 'All ESP32 devices connected',
      health: 96,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      name: 'Gemini AI Engine',
      status: 'online',
      icon: Zap,
      description: 'AI analytics responding',
      health: 94,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    },
    {
      name: 'Database System',
      status: 'online',
      icon: Database,
      description: 'SQLite operational',
      health: 99,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-100'
    },
    {
      name: 'Edge Computing',
      status: 'online',
      icon: Cpu,
      description: 'Raspberry Pi clusters active',
      health: 92,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    },
    {
      name: 'Security Layer',
      status: 'online',
      icon: Shield,
      description: 'Threat monitoring active',
      health: 97,
      color: 'text-red-600',
      bgColor: 'bg-red-100'
    }
  ];

  function getStatusColor(status: string) {
    return status === 'online' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  }

  function getHealthColor(health: number) {
    if (health >= 95) return 'text-green-600';
    if (health >= 85) return 'text-yellow-600';
    return 'text-red-600';
  }

  return (
    <Card className="card-hover">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center space-x-2">
            <Cloud className="h-5 w-5 text-blue-600" />
            <span>System Health Monitor</span>
          </span>
          <Badge className="bg-green-100 text-green-800 animate-pulse">
            All Systems Green
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* System Components */}
        <div className="space-y-4">
          {systems.map((system) => {
            const Icon = system.icon;
            return (
              <div key={system.name} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className={`${system.bgColor} p-2 rounded-lg`}>
                    <Icon className={`h-4 w-4 ${system.color}`} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900">{system.name}</p>
                    <p className="text-xs text-gray-500">{system.description}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <p className={`text-sm font-bold ${getHealthColor(system.health)}`}>
                      {system.health}%
                    </p>
                    <p className="text-xs text-gray-500">Health</p>
                  </div>
                  <Badge className={getStatusColor(system.status)}>
                    {system.status}
                  </Badge>
                </div>
              </div>
            );
          })}
        </div>

        {/* Resource Usage */}
        <div className="space-y-4 pt-4 border-t border-gray-200">
          <h4 className="font-semibold text-gray-900">Resource Utilization</h4>
          
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">CPU Usage</span>
                <span className="font-semibold">{Math.round(systemMetrics.cpuUsage)}%</span>
              </div>
              <Progress value={systemMetrics.cpuUsage} className="h-2" />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">Memory Usage</span>
                <span className="font-semibold">{Math.round(systemMetrics.memoryUsage)}%</span>
              </div>
              <Progress value={systemMetrics.memoryUsage} className="h-2" />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">Storage Usage</span>
                <span className="font-semibold">{Math.round(systemMetrics.diskUsage)}%</span>
              </div>
              <Progress value={systemMetrics.diskUsage} className="h-2" />
            </div>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">99.8%</div>
            <div className="text-xs text-gray-500">Uptime</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{Math.round(systemMetrics.networkLatency)}ms</div>
            <div className="text-xs text-gray-500">Latency</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">2.4TB</div>
            <div className="text-xs text-gray-500">Data/Day</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">94.2%</div>
            <div className="text-xs text-gray-500">AI Accuracy</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
