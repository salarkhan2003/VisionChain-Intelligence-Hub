import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Camera, Package, Truck, BarChart3, AlertTriangle, Brain, Settings, Download, Upload, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function QuickActions() {
  const navigate = useNavigate();
  const [loading, setLoading] = React.useState<string | null>(null);

  const primaryActions = [
    {
      title: 'AI Vision Detection',
      description: 'Launch theft detection & monitoring',
      icon: Camera,
      action: () => navigate('/vision'),
      color: 'from-indigo-600 to-indigo-700',
      badge: 'New AI'
    },
    {
      title: 'Smart Inventory',
      description: 'Real-time stock management',
      icon: Package,
      action: () => navigate('/inventory'),
      color: 'from-emerald-600 to-emerald-700',
      badge: 'Live'
    },
    {
      title: 'Route Optimization',
      description: 'AI-powered delivery planning',
      icon: Truck,
      action: () => navigate('/delivery'),
      color: 'from-purple-600 to-purple-700',
      badge: 'Smart'
    },
    {
      title: 'Demand Forecasting',
      description: 'Predict sales with 94% accuracy',
      icon: Brain,
      action: () => handleForecast(),
      color: 'from-pink-600 to-pink-700',
      badge: 'AI Powered'
    }
  ];

  const secondaryActions = [
    {
      title: 'Security Alerts',
      description: 'Monitor theft incidents',
      icon: AlertTriangle,
      action: () => navigate('/alerts'),
      color: 'from-red-600 to-red-700'
    },
    {
      title: 'Analytics Hub',
      description: 'Performance insights',
      icon: BarChart3,
      action: () => navigate('/analytics'),
      color: 'from-cyan-600 to-cyan-700'
    },
    {
      title: 'System Settings',
      description: 'Configure AI models',
      icon: Settings,
      action: () => handleSettings(),
      color: 'from-slate-600 to-slate-700'
    },
    {
      title: 'Export Reports',
      description: 'Download analytics data',
      icon: Download,
      action: () => handleExport(),
      color: 'from-indigo-600 to-purple-600'
    }
  ];

  const utilityActions = [
    {
      title: 'Sync Data',
      icon: RefreshCw,
      action: () => handleSync(),
      loading: 'sync'
    },
    {
      title: 'Import Data',
      icon: Upload,
      action: () => handleImport(),
      loading: 'import'
    }
  ];

  async function handleForecast() {
    setLoading('forecast');
    try {
      const response = await fetch('/api/forecast/demand', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: 1, storeId: 1 })
      });
      
      if (response.ok) {
        navigate('/analytics');
      }
    } catch (error) {
      console.error('Failed to generate forecast:', error);
    } finally {
      setLoading(null);
    }
  }

  async function handleSettings() {
    console.log('Opening system settings...');
  }

  async function handleExport() {
    setLoading('export');
    setTimeout(() => setLoading(null), 2000);
  }

  async function handleSync() {
    setLoading('sync');
    setTimeout(() => setLoading(null), 1500);
  }

  async function handleImport() {
    setLoading('import');
    setTimeout(() => setLoading(null), 2000);
  }

  return (
    <div className="space-y-6">
      {/* Primary Actions */}
      <Card className="card-hover glow-blue">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-slate-100">
            <div className="w-2 h-2 bg-indigo-400 rounded-full"></div>
            <span>AI-Powered Quick Actions</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {primaryActions.map((action) => {
              const Icon = action.icon;
              const isLoading = loading === action.title.toLowerCase().replace(' ', '');
              
              return (
                <Button
                  key={action.title}
                  variant="outline"
                  className="h-auto p-0 overflow-hidden border-0 shadow-lg interactive-element bg-slate-800/50 hover:bg-slate-700/50"
                  onClick={action.action}
                  disabled={isLoading}
                >
                  <div className={`w-full h-full bg-gradient-to-br ${action.color} p-6 text-white relative`}>
                    <div className="flex flex-col items-start space-y-3">
                      <div className="flex items-center justify-between w-full">
                        <Icon className="h-8 w-8" />
                        {action.badge && (
                          <Badge className="bg-white/20 text-white text-xs border border-white/30">
                            {action.badge}
                          </Badge>
                        )}
                      </div>
                      <div className="text-left">
                        <h3 className="font-bold text-lg">{action.title}</h3>
                        <p className="text-sm opacity-90">{action.description}</p>
                      </div>
                    </div>
                    {isLoading && (
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <RefreshCw className="h-6 w-6 animate-spin" />
                      </div>
                    )}
                  </div>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Secondary Actions */}
        <div className="lg:col-span-2">
          <Card className="card-hover glow-emerald">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-slate-100">
                <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                <span>Management Tools</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {secondaryActions.map((action) => {
                  const Icon = action.icon;
                  return (
                    <Button
                      key={action.title}
                      variant="outline"
                      className="h-20 justify-start space-x-4 interactive-element border-slate-600/50 bg-slate-800/30 hover:bg-slate-700/50 text-slate-200"
                      onClick={action.action}
                    >
                      <div className={`p-3 rounded-lg bg-gradient-to-br ${action.color}`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <div className="text-left">
                        <p className="font-semibold text-slate-100">{action.title}</p>
                        <p className="text-xs text-slate-400">{action.description}</p>
                      </div>
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Utility Actions */}
        <Card className="card-hover glow-purple">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-slate-100">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>System Utilities</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {utilityActions.map((action) => {
              const Icon = action.icon;
              const isLoading = loading === action.loading;
              
              return (
                <Button
                  key={action.title}
                  variant="outline"
                  className="w-full justify-start space-x-3 h-12 interactive-element border-slate-600/50 bg-slate-800/30 hover:bg-slate-700/50 text-slate-200"
                  onClick={action.action}
                  disabled={isLoading}
                >
                  <Icon className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                  <span>{action.title}</span>
                  {isLoading && (
                    <Badge className="bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 ml-auto">
                      Processing...
                    </Badge>
                  )}
                </Button>
              );
            })}
            
            <div className="pt-4 border-t border-slate-700">
              <div className="text-xs text-slate-400 space-y-1">
                <div>Last sync: 2 minutes ago</div>
                <div>System status: <span className="text-emerald-400 font-medium">Optimal</span></div>
                <div>AI models: <span className="text-indigo-400 font-medium">4/4 Active</span></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
