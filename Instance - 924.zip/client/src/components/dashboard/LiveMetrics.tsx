
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Activity, Zap } from 'lucide-react';

export function LiveMetrics() {
  const [metrics, setMetrics] = React.useState({
    cpuUsage: 65,
    memoryUsage: 78,
    networkThroughput: 342,
    activeConnections: 1247,
    responseTime: 24,
    errorRate: 0.2
  });

  React.useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        cpuUsage: Math.max(50, Math.min(90, prev.cpuUsage + (Math.random() - 0.5) * 10)),
        memoryUsage: Math.max(60, Math.min(85, prev.memoryUsage + (Math.random() - 0.5) * 5)),
        networkThroughput: Math.max(200, Math.min(500, prev.networkThroughput + (Math.random() - 0.5) * 50)),
        activeConnections: Math.max(1000, Math.min(1500, prev.activeConnections + Math.floor((Math.random() - 0.5) * 100))),
        responseTime: Math.max(15, Math.min(40, prev.responseTime + (Math.random() - 0.5) * 5)),
        errorRate: Math.max(0, Math.min(1, prev.errorRate + (Math.random() - 0.5) * 0.1))
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const liveMetrics = [
    {
      name: 'System CPU',
      value: `${Math.round(metrics.cpuUsage)}%`,
      progress: metrics.cpuUsage,
      icon: Activity,
      color: metrics.cpuUsage > 80 ? 'text-red-600' : metrics.cpuUsage > 60 ? 'text-yellow-600' : 'text-green-600',
      bgColor: metrics.cpuUsage > 80 ? 'bg-red-100' : metrics.cpuUsage > 60 ? 'bg-yellow-100' : 'bg-green-100'
    },
    {
      name: 'Memory Usage',
      value: `${Math.round(metrics.memoryUsage)}%`,
      progress: metrics.memoryUsage,
      icon: Zap,
      color: metrics.memoryUsage > 80 ? 'text-red-600' : 'text-blue-600',
      bgColor: metrics.memoryUsage > 80 ? 'bg-red-100' : 'bg-blue-100'
    },
    {
      name: 'Network I/O',
      value: `${Math.round(metrics.networkThroughput)} MB/s`,
      progress: (metrics.networkThroughput / 500) * 100,
      icon: TrendingUp,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    },
    {
      name: 'Active Sessions',
      value: metrics.activeConnections.toLocaleString(),
      progress: (metrics.activeConnections / 1500) * 100,
      icon: TrendingUp,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-100'
    }
  ];

  return (
    <Card className="card-hover">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center space-x-2">
            <Activity className="h-5 w-5 text-blue-600" />
            <span>Live System Metrics</span>
          </span>
          <div className="flex items-center space-x-2">
            <Badge className="bg-green-100 text-green-800 animate-pulse">
              Live
            </Badge>
            <div className="flex items-center space-x-1 text-xs text-gray-500">
              <span>Response Time:</span>
              <span className="font-bold">{Math.round(metrics.responseTime)}ms</span>
            </div>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {liveMetrics.map((metric) => {
            const Icon = metric.icon;
            return (
              <div key={metric.name} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className={`p-2 rounded-lg ${metric.bgColor}`}>
                      <Icon className={`h-4 w-4 ${metric.color}`} />
                    </div>
                    <span className="text-sm font-semibold text-gray-700">{metric.name}</span>
                  </div>
                  <span className="text-lg font-bold text-gray-900">{metric.value}</span>
                </div>
                <Progress value={metric.progress} className="h-2" />
              </div>
            );
          })}
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-green-600">99.8%</div>
              <div className="text-xs text-gray-500">Uptime</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">{Math.round(metrics.errorRate * 100) / 100}%</div>
              <div className="text-xs text-gray-500">Error Rate</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">2.4TB</div>
              <div className="text-xs text-gray-500">Data Processed</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-yellow-600">94.2%</div>
              <div className="text-xs text-gray-500">AI Accuracy</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
