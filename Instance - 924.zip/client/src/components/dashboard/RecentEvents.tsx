
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatDistanceToNow } from '@/lib/dateUtils';
import { Eye, Package, AlertTriangle, TrendingUp, Filter, RefreshCw } from 'lucide-react';

interface Event {
  id: number;
  event_type: string;
  quantity_change: number;
  timestamp: string;
  shelf_code: string;
  product_name: string;
}

export function RecentEvents() {
  const [events, setEvents] = React.useState<Event[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filter, setFilter] = React.useState<string>('all');
  const [refreshing, setRefreshing] = React.useState(false);

  React.useEffect(() => {
    fetchEvents();
    const interval = setInterval(fetchEvents, 15000);
    return () => clearInterval(interval);
  }, []);

  async function fetchEvents() {
    try {
      const response = await fetch('/api/dashboard');
      if (response.ok) {
        const data = await response.json();
        setEvents(data.recentEvents || []);
      }
    } catch (error) {
      console.error('Failed to fetch events:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleRefresh() {
    setRefreshing(true);
    await fetchEvents();
    setTimeout(() => setRefreshing(false), 1000);
  }

  function getEventBadgeColor(eventType: string) {
    switch (eventType) {
      case 'pickup': return 'bg-blue-100 text-blue-800';
      case 'restock': return 'bg-green-100 text-green-800';
      case 'theft': return 'bg-red-100 text-red-800';
      case 'misplacement': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  function getEventIcon(eventType: string) {
    switch (eventType) {
      case 'pickup': return Package;
      case 'restock': return TrendingUp;
      case 'theft': return AlertTriangle;
      case 'misplacement': return Eye;
      default: return Package;
    }
  }

  const filteredEvents = filter === 'all' ? events : events.filter(e => e.event_type === filter);
  const eventTypes = [...new Set(events.map(e => e.event_type))];

  return (
    <Card className="card-hover">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Eye className="h-5 w-5 text-blue-600" />
            <span>Live Event Stream</span>
            <Badge className="bg-green-100 text-green-800 animate-pulse">
              Real-time
            </Badge>
          </div>
          <div className="flex items-center space-x-2">
            <select 
              value={filter} 
              onChange={(e) => setFilter(e.target.value)}
              className="text-xs border border-gray-200 rounded px-2 py-1"
            >
              <option value="all">All Events</option>
              {eventTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleRefresh}
              disabled={refreshing}
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse shimmer rounded-lg p-3">
                <div className="flex items-center space-x-3">
                  <div className="h-8 w-8 bg-gray-200 rounded-lg"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                  <div className="h-4 bg-gray-200 rounded w-16"></div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredEvents.length === 0 ? (
          <div className="text-center py-8">
            <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No recent events</p>
            <p className="text-sm text-gray-400">Events will appear here in real-time</p>
          </div>
        ) : (
          <ScrollArea className="h-80">
            <div className="space-y-3 pr-4">
              {filteredEvents.map((event) => {
                const Icon = getEventIcon(event.event_type);
                return (
                  <div key={event.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors group">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${getEventBadgeColor(event.event_type).replace('text-', 'text-white bg-').split(' ')[0]}`}>
                        <Icon className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2 mb-1">
                          <Badge className={getEventBadgeColor(event.event_type)}>
                            {event.event_type}
                          </Badge>
                          <span className="text-sm font-semibold text-gray-900">
                            {event.product_name}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500">
                          {event.shelf_code} • 
                          <span className={`ml-1 font-medium ${event.quantity_change > 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {event.quantity_change > 0 ? '+' : ''}{event.quantity_change} units
                          </span>
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-gray-500 group-hover:text-gray-700">
                        {formatDistanceToNow(event.timestamp)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}
        
        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex justify-between items-center text-xs text-gray-500">
            <span>Total events: {events.length}</span>
            <span>Last updated: {new Date().toLocaleTimeString()}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
