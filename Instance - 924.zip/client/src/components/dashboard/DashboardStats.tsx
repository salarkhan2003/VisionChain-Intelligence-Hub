import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Store, Package, AlertTriangle, TrendingUp, Users, ShoppingCart, DollarSign, Zap } from 'lucide-react';

interface DashboardData {
  stores: number;
  shelves: number;
  activeAlerts: number;
  recentEvents: any[];
}

export function DashboardStats() {
  const [data, setData] = React.useState<DashboardData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [liveData, setLiveData] = React.useState({
    customers: 1247,
    sales: 45680,
    efficiency: 94.2
  });

  React.useEffect(() => {
    async function fetchDashboard() {
      try {
        const response = await fetch('/api/dashboard');
        if (response.ok) {
          const dashboardData = await response.json();
          setData(dashboardData);
        }
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchDashboard();
    
    // Update live data every 3 seconds
    const interval = setInterval(() => {
      setLiveData(prev => ({
        customers: prev.customers + Math.floor(Math.random() * 10) - 5,
        sales: prev.sales + Math.floor(Math.random() * 1000) - 500,
        efficiency: Math.max(90, Math.min(98, prev.efficiency + (Math.random() - 0.5) * 2))
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <Card key={i} className="animate-pulse shimmer bg-slate-800/50 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="h-4 bg-slate-600 rounded w-20"></div>
              <div className="h-8 w-8 bg-slate-600 rounded-lg"></div>
            </CardHeader>
            <CardContent>
              <div className="h-8 bg-slate-600 rounded w-16 mb-2"></div>
              <div className="h-3 bg-slate-600 rounded w-24"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const stats = [
    {
      name: 'Active Stores',
      value: data?.stores || 0,
      icon: Store,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-500/20',
      glowClass: 'glow-blue',
      change: '+2 new this month',
      trend: 'up'
    },
    {
      name: 'Smart Shelves',
      value: data?.shelves || 0,
      icon: Package,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/20',
      glowClass: 'glow-emerald',
      change: '+15 deployed today',
      trend: 'up'
    },
    {
      name: 'Active Alerts',
      value: data?.activeAlerts || 0,
      icon: AlertTriangle,
      color: 'text-red-400',
      bgColor: 'bg-red-500/20',
      glowClass: 'glow-pink',
      change: '-2 from yesterday',
      trend: 'down'
    },
    {
      name: 'Events Today',
      value: data?.recentEvents?.length || 0,
      icon: TrendingUp,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20',
      glowClass: 'glow-purple',
      change: '+18% vs yesterday',
      trend: 'up'
    },
    {
      name: 'Live Customers',
      value: liveData.customers.toLocaleString(),
      icon: Users,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/20',
      glowClass: 'glow-blue',
      change: 'Real-time count',
      trend: 'live',
      isLive: true
    },
    {
      name: 'Today\'s Sales',
      value: `$${(liveData.sales / 1000).toFixed(1)}K`,
      icon: DollarSign,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/20',
      glowClass: 'glow-emerald',
      change: '+12% vs target',
      trend: 'up'
    },
    {
      name: 'AI Efficiency',
      value: `${liveData.efficiency.toFixed(1)}%`,
      icon: Zap,
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/20',
      glowClass: 'glow-pink',
      change: '+2.1% this week',
      trend: 'up'
    },
    {
      name: 'Cart Conversion',
      value: '87.3%',
      icon: ShoppingCart,
      color: 'text-pink-400',
      bgColor: 'bg-pink-500/20',
      glowClass: 'glow-pink',
      change: '+5.2% improvement',
      trend: 'up'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.name} className={`card-hover relative overflow-hidden ${stat.glowClass}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-semibold text-slate-300">
                {stat.name}
              </CardTitle>
              <div className={`${stat.bgColor} p-3 rounded-xl shadow-sm border border-slate-600/30`}>
                <Icon className={`h-5 w-5 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-3xl font-bold text-slate-100 mb-1">
                    {stat.value}
                  </div>
                  <div className="flex items-center space-x-1">
                    <span className={`text-xs font-medium ${
                      stat.trend === 'up' ? 'text-emerald-400' : 
                      stat.trend === 'down' ? 'text-red-400' : 
                      stat.trend === 'live' ? 'text-cyan-400' : 'text-slate-400'
                    }`}>
                      {stat.change}
                    </span>
                    {stat.isLive && (
                      <Badge className="bg-red-500/20 text-red-400 border border-red-500/30 text-xs px-2 py-0.5 animate-pulse">
                        LIVE
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
            
            {stat.isLive && (
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent animate-pulse-slow"></div>
            )}
          </Card>
        );
      })}
    </div>
  );
}
