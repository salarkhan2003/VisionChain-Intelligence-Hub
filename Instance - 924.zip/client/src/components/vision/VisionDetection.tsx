
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Camera, Play, Square, AlertTriangle } from 'lucide-react';

export function VisionDetection() {
  const [isDetecting, setIsDetecting] = React.useState(false);
  const [selectedShelf, setSelectedShelf] = React.useState('');
  const [lastDetection, setLastDetection] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(false);

  const shelves = [
    { id: '1', code: 'A1-ELEC', location: 'Electronics Aisle 1' },
    { id: '2', code: 'B3-BEV', location: 'Beverages Aisle 3' },
    { id: '3', code: 'C2-FOOD', location: 'Groceries Aisle 2' },
    { id: '4', code: 'D1-SHOE', location: 'Footwear Aisle 1' },
    { id: '5', code: 'E4-HOME', location: 'Household Aisle 4' },
    { id: '6', code: 'F2-ELEC', location: 'Electronics Aisle 2' }
  ];

  const detectionTypes = [
    { value: 'pickup', label: 'Normal Pickup', confidence: 0.95 },
    { value: 'theft', label: 'Theft Detection', confidence: 0.85 },
    { value: 'suspicious', label: 'Suspicious Activity', confidence: 0.65 },
    { value: 'misplacement', label: 'Product Misplacement', confidence: 0.75 }
  ];

  async function simulateDetection(eventType: string, confidence: number) {
    if (!selectedShelf) return;
    
    setLoading(true);
    try {
      const response = await fetch('/api/vision/detect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          shelfId: parseInt(selectedShelf),
          eventType,
          confidenceScore: confidence,
          description: `${eventType} detected via computer vision system`
        })
      });

      if (response.ok) {
        const result = await response.json();
        setLastDetection({
          type: eventType,
          confidence,
          timestamp: new Date().toISOString(),
          aiAnalysis: result.aiAnalysis
        });
      }
    } catch (error) {
      console.error('Detection simulation failed:', error);
    } finally {
      setLoading(false);
    }
  }

  function handleStartDetection() {
    setIsDetecting(true);
    // Simulate random detection after 3-5 seconds
    setTimeout(() => {
      const randomType = detectionTypes[Math.floor(Math.random() * detectionTypes.length)];
      simulateDetection(randomType.value, randomType.confidence);
    }, 3000 + Math.random() * 2000);
  }

  function handleStopDetection() {
    setIsDetecting(false);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Camera className="h-5 w-5" />
          <span>AI Detection Controls</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="shelf-select">Select Shelf for Monitoring</Label>
          <Select value={selectedShelf} onValueChange={setSelectedShelf}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a shelf..." />
            </SelectTrigger>
            <SelectContent>
              {shelves.map((shelf) => (
                <SelectItem key={shelf.id} value={shelf.id}>
                  {shelf.code} - {shelf.location}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex space-x-3">
          <Button
            onClick={handleStartDetection}
            disabled={!selectedShelf || isDetecting}
            className="flex-1"
          >
            <Play className="h-4 w-4 mr-2" />
            Start Detection
          </Button>
          <Button
            onClick={handleStopDetection}
            disabled={!isDetecting}
            variant="outline"
            className="flex-1"
          >
            <Square className="h-4 w-4 mr-2" />
            Stop Detection
          </Button>
        </div>

        <div className="border-t pt-4">
          <h4 className="font-medium mb-3">Simulate Detection Events</h4>
          <div className="grid grid-cols-2 gap-2">
            {detectionTypes.map((type) => (
              <Button
                key={type.value}
                variant="outline"
                size="sm"
                onClick={() => simulateDetection(type.value, type.confidence)}
                disabled={!selectedShelf || loading}
                className="text-xs"
              >
                {type.label}
              </Button>
            ))}
          </div>
        </div>

        {lastDetection && (
          <div className="border-t pt-4">
            <h4 className="font-medium mb-3 flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2 text-orange-500" />
              Last Detection
            </h4>
            <div className="bg-gray-50 p-3 rounded-lg space-y-2">
              <div className="flex justify-between items-center">
                <Badge className={
                  lastDetection.type === 'theft' ? 'bg-red-100 text-red-800' :
                  lastDetection.type === 'suspicious' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-green-100 text-green-800'
                }>
                  {lastDetection.type}
                </Badge>
                <span className="text-sm text-gray-500">
                  Confidence: {Math.round(lastDetection.confidence * 100)}%
                </span>
              </div>
              <p className="text-xs text-gray-600">
                {new Date(lastDetection.timestamp).toLocaleString()}
              </p>
              {lastDetection.aiAnalysis && (
                <div className="text-xs text-gray-700 bg-white p-2 rounded border">
                  <strong>AI Analysis:</strong> {lastDetection.aiAnalysis.substring(0, 200)}...
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
