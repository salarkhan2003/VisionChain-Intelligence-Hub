
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Camera, Wifi } from 'lucide-react';

export function LiveFeed() {
  const [isLive, setIsLive] = React.useState(true);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Camera className="h-5 w-5" />
            <span>Live Camera Feed</span>
          </div>
          <Badge className={isLive ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'}>
            {isLive ? 'LIVE' : 'OFFLINE'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative bg-gray-900 rounded-lg overflow-hidden aspect-video">
          {/* Simulated camera feed */}
          <div className="absolute inset-0 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            <div className="text-center text-white space-y-4">
              <Camera className="h-16 w-16 mx-auto opacity-50" />
              <div>
                <p className="text-lg font-medium">Camera Feed Simulation</p>
                <p className="text-sm opacity-75">YOLOv8 Object Detection Active</p>
              </div>
            </div>
          </div>

          {/* Detection overlay */}
          <div className="absolute top-4 left-4 space-y-2">
            <div className="bg-black bg-opacity-70 text-white px-3 py-1 rounded text-sm">
              Resolution: 1920x1080
            </div>
            <div className="bg-black bg-opacity-70 text-white px-3 py-1 rounded text-sm">
              FPS: 30
            </div>
            <div className="bg-black bg-opacity-70 text-white px-3 py-1 rounded text-sm flex items-center">
              <Wifi className="h-3 w-3 mr-1" />
              Raspberry Pi 5
            </div>
          </div>

          {/* Status indicators */}
          <div className="absolute bottom-4 right-4 space-y-2">
            <div className="bg-green-600 text-white px-3 py-1 rounded text-sm">
              AI Model: Active
            </div>
            <div className="bg-blue-600 text-white px-3 py-1 rounded text-sm">
              Objects Detected: 12
            </div>
          </div>

          {/* Simulated detection boxes */}
          <div className="absolute top-1/3 left-1/4 w-16 h-16 border-2 border-green-400 rounded">
            <div className="bg-green-400 text-black text-xs px-1 -mt-5">
              Product: 95%
            </div>
          </div>
          
          <div className="absolute top-1/2 right-1/3 w-20 h-12 border-2 border-yellow-400 rounded">
            <div className="bg-yellow-400 text-black text-xs px-1 -mt-5">
              Person: 88%
            </div>
          </div>

          {/* Recording indicator */}
          <div className="absolute top-4 right-4">
            <div className="flex items-center space-x-2 bg-red-600 text-white px-3 py-1 rounded">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
              <span className="text-sm">REC</span>
            </div>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-green-600">98%</p>
            <p className="text-sm text-gray-600">Accuracy</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-blue-600">24ms</p>
            <p className="text-sm text-gray-600">Latency</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-purple-600">15°C</p>
            <p className="text-sm text-gray-600">Device Temp</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
