
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

export function DetectionHistory() {
  const [events, setEvents] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    async function fetchEvents() {
      try {
        const response = await fetch('/api/dashboard');
        if (response.ok) {
          const data = await response.json();
          setEvents(data.recentEvents || []);
        }
      } catch (error) {
        console.error('Failed to fetch detection history:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchEvents();
  }, []);

  function getEventBadgeColor(eventType: string) {
    switch (eventType) {
      case 'pickup': return 'bg-blue-100 text-blue-800';
      case 'restock': return 'bg-green-100 text-green-800';
      case 'theft': return 'bg-red-100 text-red-800';
      case 'misplacement': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Detection History</CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-12 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Event Type</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Shelf</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {events.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-gray-500 py-8">
                    No detection events recorded
                  </TableCell>
                </TableRow>
              ) : (
                events.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell>
                      <Badge className={getEventBadgeColor(event.event_type)}>
                        {event.event_type}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-medium">{event.product_name}</TableCell>
                    <TableCell>{event.shelf_code}</TableCell>
                    <TableCell>
                      <span className={event.quantity_change > 0 ? 'text-green-600' : 'text-red-600'}>
                        {event.quantity_change > 0 ? '+' : ''}{event.quantity_change}
                      </span>
                    </TableCell>
                    <TableCell className="text-gray-500">
                      {new Date(event.timestamp).toLocaleString()}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
